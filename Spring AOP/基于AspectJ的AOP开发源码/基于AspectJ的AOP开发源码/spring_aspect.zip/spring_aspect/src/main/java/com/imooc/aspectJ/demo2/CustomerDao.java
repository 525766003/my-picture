package com.imooc.aspectJ.demo2;

public interface CustomerDao {
    public void save();
    public String update();
    public void delete();
    public void findOne();
    public void findAll();
}
